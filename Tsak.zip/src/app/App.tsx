import { useState, type ElementType } from "react";
import {
  LayoutDashboard, CheckSquare, Mail, Users, Building2,
  LogOut, Bell, Plus, Search, MoreHorizontal, Calendar,
  Clock, Inbox, Send, Sun, Moon, Globe, Pencil, User,
  ChevronDown, Star, Settings, Eye, LayoutGrid, List,
  Menu, X, CheckCircle2, XCircle, AlertCircle, FileText,
  Shield, ArrowLeft, RefreshCw, TrendingUp, ChevronLeft,
  ChevronRight
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────
type Lang = "ar" | "en";
type Page =
  | "login" | "dashboard" | "tasks-kanban" | "tasks-list"
  | "leaves" | "email" | "employees" | "superadmin";

// ─── Translations ─────────────────────────────────────────────────
const T: Record<Lang, Record<string, string>> = {
  ar: {
    appName: "TASK Flow", tagline: "منصة إدارة المهام المؤسسية",
    dashboard: "لوحة التحكم", tasks: "المهام", taskList: "قائمة المهام",
    kanban: "لوحة كانبان", leaves: "طلبات الإجازة", email: "البريد الإلكتروني",
    inbox: "الوارد", sent: "المُرسَل", employees: "الموظفون",
    departments: "الأقسام", clients: "العملاء", auditLog: "سجل النشاط",
    settings: "الإعدادات", profile: "الملف الشخصي", superAdmin: "المشرف العام",
    companies: "الشركات", logout: "تسجيل الخروج", search: "بحث...",
    notifications: "الإشعارات", totalEmployees: "إجمالي الموظفين",
    openTasks: "المهام المفتوحة", pendingLeaves: "إجازات معلقة",
    sentEmails: "رسائل مُرسَلة", recentActivity: "النشاط الأخير",
    new: "جديد", assigned: "مُعيَّن", inProgress: "قيد التنفيذ",
    pending: "معلق", completed: "مكتمل", cancelled: "ملغى",
    low: "منخفض", medium: "متوسط", high: "عالٍ", critical: "حرج",
    approved: "موافق عليه", rejected: "مرفوض",
    loginTitle: "مرحباً بك", loginSubtitle: "سجّل دخولك للمتابعة",
    loginBtn: "تسجيل الدخول", emailLabel: "البريد الإلكتروني",
    passwordLabel: "كلمة المرور", forgotPass: "نسيت كلمة المرور؟",
    tasksByStatus: "المهام حسب الحالة", tasksByDept: "المهام حسب القسم",
    addTask: "إضافة مهمة", addEmployee: "إضافة موظف",
    requestLeave: "طلب إجازة", compose: "إنشاء رسالة",
    name: "الاسم", department: "القسم", role: "الدور",
    status: "الحالة", date: "التاريخ", priority: "الأولوية",
    assignee: "المُكلَّف", dueDate: "تاريخ الاستحقاق",
    viewAll: "عرض الكل", approve: "موافقة", reject: "رفض",
    from: "من", subject: "الموضوع", companyName: "اسم الشركة",
    plan: "الباقة", main: "الرئيسية", hr: "الموارد البشرية",
    communication: "التواصل", administration: "الإدارة",
    noEmailSelected: "اختر رسالة للعرض", reply: "رد",
    leaveType: "نوع الإجازة", startDate: "تاريخ البدء",
    endDate: "تاريخ الانتهاء", days: "أيام",
    enterprise: "مؤسسة", professional: "احترافية", starter: "أساسية",
    activeUsers: "مستخدمون نشطون",
    emailPlaceholder: "admin@company.com", passwordPlaceholder: "••••••••",
    noTasks: "لا توجد مهام", totalTasks: "مهمة إجمالية", tasks_count: "مهمة",
    employees_count: "موظف", requests: "طلب",
  },
  en: {
    appName: "TASK Flow", tagline: "Enterprise Workflow Platform",
    dashboard: "Dashboard", tasks: "Tasks", taskList: "Task List",
    kanban: "Kanban Board", leaves: "Leave Requests", email: "Email",
    inbox: "Inbox", sent: "Sent", employees: "Employees",
    departments: "Departments", clients: "Clients", auditLog: "Audit Log",
    settings: "Settings", profile: "Profile", superAdmin: "Super Admin",
    companies: "Companies", logout: "Logout", search: "Search...",
    notifications: "Notifications", totalEmployees: "Total Employees",
    openTasks: "Open Tasks", pendingLeaves: "Pending Leaves",
    sentEmails: "Sent Emails", recentActivity: "Recent Activity",
    new: "New", assigned: "Assigned", inProgress: "In Progress",
    pending: "Pending", completed: "Completed", cancelled: "Cancelled",
    low: "Low", medium: "Medium", high: "High", critical: "Critical",
    approved: "Approved", rejected: "Rejected",
    loginTitle: "Welcome back", loginSubtitle: "Sign in to your account",
    loginBtn: "Sign In", emailLabel: "Email",
    passwordLabel: "Password", forgotPass: "Forgot password?",
    tasksByStatus: "Tasks by Status", tasksByDept: "Tasks by Department",
    addTask: "Add Task", addEmployee: "Add Employee",
    requestLeave: "Request Leave", compose: "Compose",
    name: "Name", department: "Department", role: "Role",
    status: "Status", date: "Date", priority: "Priority",
    assignee: "Assignee", dueDate: "Due Date",
    viewAll: "View All", approve: "Approve", reject: "Reject",
    from: "From", subject: "Subject", companyName: "Company Name",
    plan: "Plan", main: "Main", hr: "Human Resources",
    communication: "Communication", administration: "Administration",
    noEmailSelected: "Select an email to view", reply: "Reply",
    leaveType: "Leave Type", startDate: "Start Date",
    endDate: "End Date", days: "days",
    enterprise: "Enterprise", professional: "Professional", starter: "Starter",
    activeUsers: "Active Users",
    emailPlaceholder: "admin@company.com", passwordPlaceholder: "••••••••",
    noTasks: "No tasks", totalTasks: "total tasks", tasks_count: "tasks",
    employees_count: "employees", requests: "requests",
  },
};

// ─── Mock Data ────────────────────────────────────────────────────
const EMPLOYEES = [
  { id: 1, name: "أحمد محمد العلي", nameEn: "Ahmed Al-Ali", dept: "IT", deptEn: "IT", role: "manager", avatar: "أ", color: "bg-blue-500", email: "ahmed@company.com", status: "active" },
  { id: 2, name: "سارة خالد الفارسي", nameEn: "Sara Al-Farsi", dept: "الموارد البشرية", deptEn: "HR", role: "manager", avatar: "س", color: "bg-purple-500", email: "sara@company.com", status: "active" },
  { id: 3, name: "محمد عبدالله الحربي", nameEn: "Mohammed Al-Harbi", dept: "المبيعات", deptEn: "Sales", role: "employee", avatar: "م", color: "bg-green-500", email: "mohammed@company.com", status: "active" },
  { id: 4, name: "نورة سلطان العتيبي", nameEn: "Noura Al-Otaibi", dept: "المالية", deptEn: "Finance", role: "employee", avatar: "ن", color: "bg-pink-500", email: "noura@company.com", status: "active" },
  { id: 5, name: "خالد عمر الدوسري", nameEn: "Khalid Al-Dosari", dept: "التسويق", deptEn: "Marketing", role: "employee", avatar: "خ", color: "bg-orange-500", email: "khalid@company.com", status: "inactive" },
  { id: 6, name: "فاطمة علي الزهراني", nameEn: "Fatima Al-Zahrani", dept: "IT", deptEn: "IT", role: "employee", avatar: "ف", color: "bg-teal-500", email: "fatima@company.com", status: "active" },
  { id: 7, name: "عبدالرحمن يوسف النجار", nameEn: "Abdulrahman Al-Najjar", dept: "العمليات", deptEn: "Operations", role: "manager", avatar: "ع", color: "bg-indigo-500", email: "ar@company.com", status: "active" },
];

const TASKS = [
  { id: 1, title: "تطوير واجهة المستخدم", titleEn: "Develop UI Interface", status: "inProgress", priority: "high", assignee: "أحمد", assigneeEn: "Ahmed", dueDate: "١٠/٠٧/٢٠٢٦", dueDateEn: "07/10/2026", dept: "IT", avatarColor: "bg-blue-500" },
  { id: 2, title: "مراجعة تقارير المبيعات", titleEn: "Review Sales Reports", status: "new", priority: "medium", assignee: "سارة", assigneeEn: "Sara", dueDate: "٠٥/٠٧/٢٠٢٦", dueDateEn: "07/05/2026", dept: "Sales", avatarColor: "bg-purple-500" },
  { id: 3, title: "تحديث نظام الرواتب", titleEn: "Update Payroll System", status: "assigned", priority: "critical", assignee: "نورة", assigneeEn: "Noura", dueDate: "٠٨/٠٧/٢٠٢٦", dueDateEn: "07/08/2026", dept: "Finance", avatarColor: "bg-pink-500" },
  { id: 4, title: "إعداد خطة التسويق", titleEn: "Prepare Marketing Plan", status: "inProgress", priority: "high", assignee: "خالد", assigneeEn: "Khalid", dueDate: "١٥/٠٧/٢٠٢٦", dueDateEn: "07/15/2026", dept: "Marketing", avatarColor: "bg-orange-500" },
  { id: 5, title: "صيانة الخوادم", titleEn: "Server Maintenance", status: "completed", priority: "medium", assignee: "فاطمة", assigneeEn: "Fatima", dueDate: "٣٠/٠٦/٢٠٢٦", dueDateEn: "06/30/2026", dept: "IT", avatarColor: "bg-teal-500" },
  { id: 6, title: "توظيف مطور جديد", titleEn: "Hire New Developer", status: "pending", priority: "low", assignee: "محمد", assigneeEn: "Mohammed", dueDate: "٢٠/٠٧/٢٠٢٦", dueDateEn: "07/20/2026", dept: "HR", avatarColor: "bg-green-500" },
  { id: 7, title: "مراجعة عقود الموردين", titleEn: "Review Supplier Contracts", status: "new", priority: "medium", assignee: "عبدالرحمن", assigneeEn: "Abdulrahman", dueDate: "١٢/٠٧/٢٠٢٦", dueDateEn: "07/12/2026", dept: "Operations", avatarColor: "bg-indigo-500" },
  { id: 8, title: "تدريب فريق المبيعات", titleEn: "Sales Team Training", status: "assigned", priority: "high", assignee: "سارة", assigneeEn: "Sara", dueDate: "١٨/٠٧/٢٠٢٦", dueDateEn: "07/18/2026", dept: "HR", avatarColor: "bg-purple-500" },
  { id: 9, title: "تحليل بيانات العملاء", titleEn: "Analyze Customer Data", status: "inProgress", priority: "critical", assignee: "أحمد", assigneeEn: "Ahmed", dueDate: "٠٧/٠٧/٢٠٢٦", dueDateEn: "07/07/2026", dept: "Sales", avatarColor: "bg-blue-500" },
  { id: 10, title: "إطلاق الحملة الإعلانية", titleEn: "Launch Ad Campaign", status: "cancelled", priority: "high", assignee: "خالد", assigneeEn: "Khalid", dueDate: "٢٥/٠٦/٢٠٢٦", dueDateEn: "06/25/2026", dept: "Marketing", avatarColor: "bg-orange-500" },
  { id: 11, title: "تحديث سياسة الأمان", titleEn: "Update Security Policy", status: "new", priority: "critical", assignee: "فاطمة", assigneeEn: "Fatima", dueDate: "٠١/٠٧/٢٠٢٦", dueDateEn: "07/01/2026", dept: "IT", avatarColor: "bg-teal-500" },
];

const LEAVES = [
  { id: 1, employee: "محمد عبدالله الحربي", employeeEn: "Mohammed Al-Harbi", type: "سنوية", typeEn: "Annual", start: "٠١/٠٧/٢٠٢٦", end: "٠٧/٠٧/٢٠٢٦", days: 7, status: "pending", avatar: "م", color: "bg-green-500" },
  { id: 2, employee: "نورة سلطان العتيبي", employeeEn: "Noura Al-Otaibi", type: "مرضية", typeEn: "Sick", start: "٢٨/٠٦/٢٠٢٦", end: "٣٠/٠٦/٢٠٢٦", days: 3, status: "approved", avatar: "ن", color: "bg-pink-500" },
  { id: 3, employee: "فاطمة علي الزهراني", employeeEn: "Fatima Al-Zahrani", type: "طارئة", typeEn: "Emergency", start: "٢٧/٠٦/٢٠٢٦", end: "٢٧/٠٦/٢٠٢٦", days: 1, status: "approved", avatar: "ف", color: "bg-teal-500" },
  { id: 4, employee: "خالد عمر الدوسري", employeeEn: "Khalid Al-Dosari", type: "سنوية", typeEn: "Annual", start: "١٥/٠٧/٢٠٢٦", end: "٢٢/٠٧/٢٠٢٦", days: 8, status: "rejected", avatar: "خ", color: "bg-orange-500" },
  { id: 5, employee: "عبدالرحمن يوسف النجار", employeeEn: "Abdulrahman Al-Najjar", type: "سنوية", typeEn: "Annual", start: "٠١/٠٨/٢٠٢٦", end: "١٤/٠٨/٢٠٢٦", days: 14, status: "pending", avatar: "ع", color: "bg-indigo-500" },
];

const EMAILS = [
  {
    id: 1, from: "أحمد محمد العلي", fromEn: "Ahmed Al-Ali", avatar: "أ", color: "bg-blue-500",
    fromEmail: "ahmed@company.com", subject: "تقرير أداء الفريق للربع الثاني", subjectEn: "Q2 Team Performance Report",
    preview: "السلام عليكم، أرفق لكم تقرير أداء الفريق للربع الثاني من العام الحالي.",
    time: "١٠:٣٠ ص", read: false, starred: true,
    body: "السلام عليكم ورحمة الله وبركاته،\n\nأرفق لكم تقرير أداء الفريق للربع الثاني. يُظهر التقرير تحسناً ملحوظاً في مستوى إنجاز المهام بنسبة ٢٣٪ مقارنة بالربع الأول.\n\nأبرز النتائج:\n• إنجاز ٨٧٪ من المهام في الوقت المحدد\n• انخفاض معدل التأخير بنسبة ١٥٪\n• تحسن التواصل بين الأقسام\n\nمع خالص التحيات،\nأحمد محمد العلي",
    bodyEn: "Dear Team,\n\nPlease find attached the Q2 team performance report. The report shows a notable 23% improvement in task completion compared to Q1.\n\nKey highlights:\n• 87% of tasks completed on time\n• 15% reduction in delay rate\n• Improved cross-department communication\n\nBest regards,\nAhmed Al-Ali",
  },
  {
    id: 2, from: "سارة خالد الفارسي", fromEn: "Sara Al-Farsi", avatar: "س", color: "bg-purple-500",
    fromEmail: "sara@company.com", subject: "طلب موافقة على ميزانية التدريب", subjectEn: "Training Budget Approval Request",
    preview: "المحترم، نرجو الموافقة على ميزانية التدريب المقترحة للربع القادم.",
    time: "أمس", read: true, starred: false,
    body: "المحترم،\n\nأرجو الاطلاع على الميزانية المقترحة لبرنامج التدريب للربع الثالث:\n\n• تدريب القيادة: ١٥,٠٠٠ ريال\n• تطوير المهارات التقنية: ٢٢,٠٠٠ ريال\n• ورش العمل الإبداعية: ٨,٠٠٠ ريال\n\nالمجموع: ٤٥,٠٠٠ ريال\n\nنأمل الموافقة لضمان تطوير كوادرنا البشرية.\n\nشكراً،\nسارة",
    bodyEn: "Dear Manager,\n\nPlease review the proposed training budget for Q3:\n\n• Leadership Training: SAR 15,000\n• Technical Skills Development: SAR 22,000\n• Creative Workshops: SAR 8,000\n\nTotal: SAR 45,000\n\nYour approval is needed to ensure our team's development.\n\nThank you,\nSara",
  },
  {
    id: 3, from: "محمد عبدالله الحربي", fromEn: "Mohammed Al-Harbi", avatar: "م", color: "bg-green-500",
    fromEmail: "mohammed@company.com", subject: "اجتماع الفريق الأسبوعي", subjectEn: "Weekly Team Meeting",
    preview: "نذكركم بموعد اجتماع الفريق الأسبوعي غداً الساعة التاسعة صباحاً.",
    time: "أمس", read: true, starred: false,
    body: "عزيزي الفريق،\n\nنذكركم بموعد اجتماعنا الأسبوعي:\n\n📅 الموعد: الأحد القادم\n⏰ الساعة: ٩:٠٠ صباحاً\n📍 قاعة الاجتماعات الرئيسية\n\nجدول الأعمال:\n١. مراجعة المهام الأسبوعية\n٢. تحديثات المشاريع\n٣. التخطيط للأسبوع القادم\n\nيرجى الحضور في الموعد المحدد.\n\nمحمد",
    bodyEn: "Dear Team,\n\nReminder of our weekly meeting:\n\n📅 Date: Next Sunday\n⏰ Time: 9:00 AM\n📍 Main Conference Room\n\nAgenda:\n1. Weekly task review\n2. Project updates\n3. Next week planning\n\nPlease attend on time.\n\nMohammed",
  },
  {
    id: 4, from: "فريق الدعم التقني", fromEn: "System Admin", avatar: "S", color: "bg-slate-500",
    fromEmail: "admin@system.com", subject: "تحديث النظام المجدول", subjectEn: "Scheduled System Update",
    preview: "سيتم إجراء صيانة مجدولة للنظام يوم الجمعة من ١٢ منتصف الليل إلى ٢ ص.",
    time: "منذ ٣ أيام", read: true, starred: false,
    body: "إشعار النظام،\n\nسيتم إجراء صيانة دورية:\n\n⏰ الوقت: الجمعة ١٢:٠٠ منتصف الليل — ٢:٠٠ صباحاً\n⚠️ قد يتعذر الوصول إلى النظام خلال هذه الفترة\n\nيُرجى حفظ جميع أعمالكم مسبقاً.\n\nشكراً لتفهمكم،\nفريق الدعم التقني",
    bodyEn: "System Notice,\n\nScheduled maintenance will be performed:\n\n⏰ Time: Friday 12:00 AM — 2:00 AM\n⚠️ System may be inaccessible during this period\n\nPlease save all your work beforehand.\n\nThank you for your understanding,\nTech Support Team",
  },
  {
    id: 5, from: "نورة سلطان العتيبي", fromEn: "Noura Al-Otaibi", avatar: "ن", color: "bg-pink-500",
    fromEmail: "noura@company.com", subject: "تقرير المصروفات الشهرية", subjectEn: "Monthly Expense Report",
    preview: "بالرجاء الاطلاع على تقرير المصروفات الشهرية المرفق للمراجعة والاعتماد.",
    time: "منذ ٤ أيام", read: true, starred: true,
    body: "تحية طيبة،\n\nتقرير المصروفات — يونيو ٢٠٢٦:\n\nإجمالي المصروفات: ١٢٣,٤٥٦ ريال\n\n• رواتب: ٩٥,٠٠٠ ريال (٧٧٪)\n• مصروفات التشغيل: ١٨,٤٥٦ ريال (١٥٪)\n• تطوير وتدريب: ١٠,٠٠٠ ريال (٨٪)\n\nيُرجى المراجعة والاعتماد.\n\nنورة",
    bodyEn: "Dear Manager,\n\nExpense Report — June 2026:\n\nTotal Expenses: SAR 123,456\n\n• Salaries: SAR 95,000 (77%)\n• Operating Expenses: SAR 18,456 (15%)\n• Training & Development: SAR 10,000 (8%)\n\nPlease review and approve.\n\nNoura",
  },
];

const COMPANIES = [
  { id: 1, name: "شركة التقنية المتقدمة", nameEn: "Advanced Tech Co.", employees: 145, activeUsers: 132, plan: "enterprise", status: "active", admin: "علي الأحمد", adminEn: "Ali Al-Ahmad" },
  { id: 2, name: "مجموعة الأعمال الرائدة", nameEn: "Leading Business Group", employees: 87, activeUsers: 79, plan: "professional", status: "active", admin: "هند الراشد", adminEn: "Hind Al-Rashid" },
  { id: 3, name: "شركة الخدمات الذكية", nameEn: "Smart Services Co.", employees: 34, activeUsers: 28, plan: "starter", status: "trial", admin: "فيصل الحربي", adminEn: "Faisal Al-Harbi" },
  { id: 4, name: "مؤسسة البناء والتطوير", nameEn: "Build & Dev Foundation", employees: 210, activeUsers: 198, plan: "enterprise", status: "active", admin: "منى العتيبي", adminEn: "Mona Al-Otaibi" },
];

const ACTIVITIES: { id: number; user: string; userEn: string; action: string; actionEn: string; target: string; time: string; icon: ElementType; color: string }[] = [
  { id: 1, user: "أحمد", userEn: "Ahmed", action: "أضاف مهمة جديدة", actionEn: "added a new task", target: '"تطوير واجهة المستخدم"', time: "منذ ١٠ د", icon: CheckSquare, color: "text-blue-500" },
  { id: 2, user: "سارة", userEn: "Sara", action: "وافقت على طلب إجازة", actionEn: "approved leave for", target: "نورة العتيبي", time: "منذ ٢٥ د", icon: CheckCircle2, color: "text-green-500" },
  { id: 3, user: "محمد", userEn: "Mohammed", action: "أرسل رسالة إلى", actionEn: "sent email to", target: "فريق المبيعات", time: "منذ ساعة", icon: Mail, color: "text-purple-500" },
  { id: 4, user: "نورة", userEn: "Noura", action: "أكملت المهمة", actionEn: "completed task", target: '"صيانة الخوادم"', time: "منذ ٢ س", icon: CheckCircle2, color: "text-green-500" },
  { id: 5, user: "خالد", userEn: "Khalid", action: "أضاف موظفاً جديداً", actionEn: "added new employee", target: "فاطمة الزهراني", time: "منذ ٣ س", icon: Users, color: "text-orange-500" },
  { id: 6, user: "فاطمة", userEn: "Fatima", action: "حدّثت حالة المهمة", actionEn: "updated task status", target: '"صيانة الخوادم"', time: "منذ ٥ س", icon: RefreshCw, color: "text-blue-500" },
];

// ─── Chart Data ───────────────────────────────────────────────────
const STATUS_CHART = [
  { name: "جديد", nameEn: "New", value: 3, fill: "#94A3B8" },
  { name: "مُعيَّن", nameEn: "Assigned", value: 2, fill: "#3B82F6" },
  { name: "قيد التنفيذ", nameEn: "In Progress", value: 3, fill: "#F59E0B" },
  { name: "معلق", nameEn: "Pending", value: 1, fill: "#8B5CF6" },
  { name: "مكتمل", nameEn: "Completed", value: 1, fill: "#22C55E" },
  { name: "ملغى", nameEn: "Cancelled", value: 1, fill: "#EF4444" },
];
const DEPT_CHART = [
  { nameAr: "التقنية", name: "IT", tasks: 3, fill: "#2563EB" },
  { nameAr: "المبيعات", name: "Sales", tasks: 2, fill: "#22C55E" },
  { nameAr: "المالية", name: "Finance", tasks: 1, fill: "#F59E0B" },
  { nameAr: "التسويق", name: "Marketing", tasks: 2, fill: "#EF4444" },
  { nameAr: "الموارد", name: "HR", tasks: 2, fill: "#8B5CF6" },
  { nameAr: "العمليات", name: "Operations", tasks: 1, fill: "#EC4899" },
];

// ─── Config ────────────────────────────────────────────────────────
const STATUS_CFG: Record<string, { bg: string; text: string; arLabel: string; enLabel: string }> = {
  new: { bg: "bg-slate-100 dark:bg-slate-700", text: "text-slate-700 dark:text-slate-200", arLabel: "جديد", enLabel: "New" },
  assigned: { bg: "bg-blue-100 dark:bg-blue-900/50", text: "text-blue-700 dark:text-blue-300", arLabel: "مُعيَّن", enLabel: "Assigned" },
  inProgress: { bg: "bg-amber-100 dark:bg-amber-900/50", text: "text-amber-700 dark:text-amber-300", arLabel: "قيد التنفيذ", enLabel: "In Progress" },
  pending: { bg: "bg-purple-100 dark:bg-purple-900/50", text: "text-purple-700 dark:text-purple-300", arLabel: "معلق", enLabel: "Pending" },
  completed: { bg: "bg-green-100 dark:bg-green-900/50", text: "text-green-700 dark:text-green-300", arLabel: "مكتمل", enLabel: "Completed" },
  cancelled: { bg: "bg-red-100 dark:bg-red-900/50", text: "text-red-700 dark:text-red-300", arLabel: "ملغى", enLabel: "Cancelled" },
  approved: { bg: "bg-green-100 dark:bg-green-900/50", text: "text-green-700 dark:text-green-300", arLabel: "موافق عليه", enLabel: "Approved" },
  rejected: { bg: "bg-red-100 dark:bg-red-900/50", text: "text-red-700 dark:text-red-300", arLabel: "مرفوض", enLabel: "Rejected" },
  active: { bg: "bg-green-100 dark:bg-green-900/50", text: "text-green-700 dark:text-green-300", arLabel: "نشط", enLabel: "Active" },
  inactive: { bg: "bg-slate-100 dark:bg-slate-700", text: "text-slate-500 dark:text-slate-400", arLabel: "غير نشط", enLabel: "Inactive" },
  trial: { bg: "bg-blue-100 dark:bg-blue-900/50", text: "text-blue-700 dark:text-blue-300", arLabel: "تجريبي", enLabel: "Trial" },
};
const PRIORITY_CFG: Record<string, { bg: string; text: string; dot: string; arLabel: string; enLabel: string }> = {
  low: { bg: "bg-slate-100 dark:bg-slate-700", text: "text-slate-600 dark:text-slate-300", dot: "bg-slate-400", arLabel: "منخفض", enLabel: "Low" },
  medium: { bg: "bg-blue-100 dark:bg-blue-900/50", text: "text-blue-700 dark:text-blue-300", dot: "bg-blue-500", arLabel: "متوسط", enLabel: "Medium" },
  high: { bg: "bg-orange-100 dark:bg-orange-900/50", text: "text-orange-700 dark:text-orange-300", dot: "bg-orange-500", arLabel: "عالٍ", enLabel: "High" },
  critical: { bg: "bg-red-100 dark:bg-red-900/50", text: "text-red-700 dark:text-red-300", dot: "bg-red-500", arLabel: "حرج", enLabel: "Critical" },
};

// ─── Reusable Components ──────────────────────────────────────────
function StatusBadge({ status, lang }: { status: string; lang: Lang }) {
  const c = STATUS_CFG[status] ?? STATUS_CFG.new;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${c.bg} ${c.text}`}>
      {lang === "ar" ? c.arLabel : c.enLabel}
    </span>
  );
}
function PriorityBadge({ priority, lang }: { priority: string; lang: Lang }) {
  const c = PRIORITY_CFG[priority] ?? PRIORITY_CFG.medium;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c.dot}`} />
      {lang === "ar" ? c.arLabel : c.enLabel}
    </span>
  );
}
function Av({ letter, color, size = "md" }: { letter: string; color: string; size?: "sm" | "md" | "lg" }) {
  const s = { sm: "w-7 h-7 text-xs", md: "w-9 h-9 text-sm", lg: "w-12 h-12 text-base" }[size];
  return (
    <div className={`${s} ${color} rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0`}>
      {letter}
    </div>
  );
}

// ─── LoginPage ────────────────────────────────────────────────────
function LoginPage({ t, lang, setLang, dark, setDark, onLogin }: {
  t: Record<string, string>; lang: Lang;
  setLang: (l: Lang) => void; dark: boolean;
  setDark: (d: boolean) => void; onLogin: () => void;
}) {
  const [email, setEmail] = useState("admin@company.com");
  const [password, setPassword] = useState("••••••••");
  return (
    <div className="h-screen flex overflow-hidden bg-background" dir="ltr">
      {/* Brand panel */}
      <div
        className="hidden lg:flex flex-1 relative overflow-hidden flex-col justify-center px-16"
        style={{ background: "linear-gradient(145deg, #1E3A8A 0%, #2563EB 45%, #3B82F6 80%, #1D4ED8 100%)" }}
      >
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }} />
          <div className="absolute -bottom-16 -left-16 w-80 h-80 rounded-full" style={{ background: "rgba(255,255,255,0.05)" }} />
          <div className="absolute top-1/2 right-12 w-48 h-48 rounded-full" style={{ background: "rgba(255,255,255,0.04)" }} />
        </div>
        <div className="relative z-10 text-white max-w-md">
          <div className="flex items-center gap-3 mb-14">
            <div className="w-11 h-11 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <CheckSquare className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight">TASK Flow</span>
          </div>
          <h1 className="text-4xl font-bold mb-5 leading-tight">
            {lang === "ar" ? "منصة إدارة\nالمهام المؤسسية" : "Enterprise Workflow\n& Communication"}
          </h1>
          <p className="text-blue-100 text-lg mb-14 leading-relaxed">
            {lang === "ar"
              ? "نظام متكامل لإدارة المهام والتواصل وتتبع الأداء في بيئة العمل الحديثة"
              : "A complete system for task management, communication, and performance tracking"}
          </p>
          <div className="grid grid-cols-3 gap-4">
            {[
              { n: lang === "ar" ? "+١٢٠٠" : "1,200+", l: lang === "ar" ? "مهمة مكتملة" : "Tasks Done", I: CheckSquare },
              { n: lang === "ar" ? "+٤٧٦" : "476+", l: lang === "ar" ? "موظف نشط" : "Active Users", I: Users },
              { n: lang === "ar" ? "+٤" : "4+", l: lang === "ar" ? "شركة" : "Companies", I: Building2 },
            ].map(({ n, l, I }) => (
              <div key={l} className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm border border-white/10">
                <I className="w-5 h-5 text-blue-200 mb-2" />
                <div className="text-2xl font-bold">{n}</div>
                <div className="text-sm text-blue-200 mt-0.5">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Form panel */}
      <div className="w-full lg:w-[480px] flex flex-col bg-card overflow-y-auto">
        <div className="flex items-center justify-between p-5">
          <div className="flex items-center gap-2 lg:hidden">
            <div className="w-8 h-8 bg-primary/10 rounded-xl flex items-center justify-center">
              <CheckSquare className="w-4 h-4 text-primary" />
            </div>
            <span className="font-bold text-foreground">TASK Flow</span>
          </div>
          <div className="flex items-center gap-1.5 ms-auto">
            <button onClick={() => setDark(!dark)} className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-muted transition-colors text-muted-foreground">
              {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button onClick={() => setLang(lang === "ar" ? "en" : "ar")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-muted transition-colors text-sm font-medium text-muted-foreground">
              <Globe className="w-4 h-4" />
              {lang === "ar" ? "EN" : "عربي"}
            </button>
          </div>
        </div>

        <div className="flex-1 flex flex-col justify-center px-10 lg:px-14 pb-14" dir={lang === "ar" ? "rtl" : "ltr"}>
          <div className="mb-10">
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-6">
              <CheckSquare className="w-7 h-7 text-primary" />
            </div>
            <h2 className="text-3xl font-bold text-foreground">{t.loginTitle}</h2>
            <p className="text-muted-foreground mt-2">{t.loginSubtitle}</p>
          </div>
          <div className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">{t.emailLabel}</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder={t.emailPlaceholder}
                className="w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">{t.passwordLabel}</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder={t.passwordPlaceholder}
                className="w-full px-4 py-3 rounded-xl border border-border bg-input-background text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm"
              />
            </div>
            <div className="flex justify-end">
              <button className="text-sm text-primary hover:underline font-medium">{t.forgotPass}</button>
            </div>
            <button onClick={onLogin}
              className="w-full py-3.5 bg-primary text-primary-foreground rounded-xl font-semibold hover:bg-primary/90 active:scale-[0.98] transition-all focus:outline-none focus:ring-2 focus:ring-primary/40 shadow-md shadow-primary/20"
            >
              {t.loginBtn}
            </button>
          </div>
          <p className="mt-10 text-center text-xs text-muted-foreground">
            {lang === "ar" ? "© ٢٠٢٦ TASK Flow. جميع الحقوق محفوظة." : "© 2026 TASK Flow. All rights reserved."}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── DashboardPage ────────────────────────────────────────────────
function DashboardPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const statsChartData = STATUS_CHART.map(d => ({ name: lang === "ar" ? d.name : d.nameEn, value: d.value, fill: d.fill }));
  const deptChartData = DEPT_CHART.map(d => ({ name: lang === "ar" ? d.nameAr : d.name, tasks: d.tasks, fill: d.fill }));

  const STAT_CARDS = [
    { label: t.totalEmployees, value: lang === "ar" ? "٧" : "7", change: lang === "ar" ? "+٢ هذا الشهر" : "+2 this month", positive: true, I: Users, accent: "blue" },
    { label: t.openTasks, value: lang === "ar" ? "٩" : "9", change: lang === "ar" ? "+٣ اليوم" : "+3 today", positive: true, I: CheckSquare, accent: "amber" },
    { label: t.pendingLeaves, value: lang === "ar" ? "٢" : "2", change: lang === "ar" ? "طلبات جديدة" : "new requests", positive: false, I: Calendar, accent: "purple" },
    { label: t.sentEmails, value: lang === "ar" ? "٢٤" : "24", change: lang === "ar" ? "+٥ هذا الأسبوع" : "+5 this week", positive: true, I: Mail, accent: "green" },
  ];
  const accentMap: Record<string, { icon: string; bg: string; badge: string }> = {
    blue:   { icon: "text-blue-500",   bg: "bg-blue-50 dark:bg-blue-900/20",   badge: "" },
    amber:  { icon: "text-amber-500",  bg: "bg-amber-50 dark:bg-amber-900/20", badge: "" },
    purple: { icon: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/20", badge: "" },
    green:  { icon: "text-green-500",  bg: "bg-green-50 dark:bg-green-900/20", badge: "" },
  };

  return (
    <div className="p-6 space-y-6">
      {/* Stat cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {STAT_CARDS.map(s => {
          const ac = accentMap[s.accent];
          const Icon = s.I;
          return (
            <div key={s.label} className="bg-card rounded-2xl border border-border p-5 hover:shadow-md transition-shadow group">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-11 h-11 ${ac.bg} rounded-xl flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${ac.icon}`} />
                </div>
                <TrendingUp className={`w-4 h-4 ${s.positive ? "text-green-500" : "text-red-400"}`} />
              </div>
              <div className="text-3xl font-bold text-foreground">{s.value}</div>
              <div className="text-sm font-medium text-muted-foreground mt-1">{s.label}</div>
              <div className={`text-xs mt-2 font-medium ${s.positive ? "text-green-500" : "text-red-400"}`}>{s.change}</div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-2xl border border-border p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">{t.tasksByStatus}</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={statsChartData} barSize={24}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} width={20} />
              <Tooltip
                contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "0.75rem", fontSize: "12px", boxShadow: "0 4px 20px rgba(0,0,0,0.08)" }}
                cursor={{ fill: "var(--muted)", opacity: 0.4 }}
              />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {statsChartData.map((e, i) => <Cell key={i} fill={e.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">{t.tasksByDept}</h3>
          <div className="flex items-center gap-2">
            <ResponsiveContainer width="55%" height={180}>
              <PieChart>
                <Pie data={deptChartData} dataKey="tasks" nameKey="name" cx="50%" cy="50%" innerRadius={44} outerRadius={72} strokeWidth={3} stroke="var(--card)">
                  {deptChartData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: "0.75rem", fontSize: "12px" }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2.5">
              {deptChartData.map(d => (
                <div key={d.name} className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.fill }} />
                    <span className="text-xs text-muted-foreground">{d.name}</span>
                  </div>
                  <span className="text-xs font-bold text-foreground">{d.tasks}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-card rounded-2xl border border-border p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground">{t.recentActivity}</h3>
          <button className="text-xs text-primary hover:underline font-medium">{t.viewAll}</button>
        </div>
        <div className="space-y-1">
          {ACTIVITIES.map(act => {
            const Icon = act.icon;
            return (
              <div key={act.id} className="flex items-center gap-3 py-2.5 border-b border-border/50 last:border-0 group hover:bg-muted/30 rounded-xl px-2 -mx-2 transition-colors">
                <div className="w-8 h-8 bg-muted rounded-xl flex items-center justify-center flex-shrink-0">
                  <Icon className={`w-4 h-4 ${act.color}`} />
                </div>
                <p className="flex-1 text-sm text-foreground min-w-0">
                  <span className="font-semibold">{lang === "ar" ? act.user : act.userEn}</span>{" "}
                  <span className="text-muted-foreground">{lang === "ar" ? act.action : act.actionEn}</span>{" "}
                  <span className="font-medium">{act.target}</span>
                </p>
                <span className="text-xs text-muted-foreground flex-shrink-0">{act.time}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── KanbanPage ───────────────────────────────────────────────────
function KanbanPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const [selected, setSelected] = useState<number | null>(null);
  const COLS = [
    { key: "new",        label: lang === "ar" ? "جديد" : "New",            dot: "bg-slate-400",  hdr: "bg-slate-50 dark:bg-slate-800/60" },
    { key: "assigned",   label: lang === "ar" ? "مُعيَّن" : "Assigned",       dot: "bg-blue-500",   hdr: "bg-blue-50 dark:bg-blue-900/20" },
    { key: "inProgress", label: lang === "ar" ? "قيد التنفيذ" : "In Progress", dot: "bg-amber-500",  hdr: "bg-amber-50 dark:bg-amber-900/20" },
    { key: "pending",    label: lang === "ar" ? "معلق" : "Pending",         dot: "bg-purple-500", hdr: "bg-purple-50 dark:bg-purple-900/20" },
    { key: "completed",  label: lang === "ar" ? "مكتمل" : "Completed",       dot: "bg-green-500",  hdr: "bg-green-50 dark:bg-green-900/20" },
    { key: "cancelled",  label: lang === "ar" ? "ملغى" : "Cancelled",       dot: "bg-red-400",    hdr: "bg-red-50 dark:bg-red-900/20" },
  ];
  return (
    <div className="p-6 flex flex-col h-full">
      <div className="flex items-center justify-between mb-6 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t.kanban}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{TASKS.length} {t.totalTasks}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20">
          <Plus className="w-4 h-4" />
          {t.addTask}
        </button>
      </div>
      <div className="flex-1 min-h-0 overflow-x-auto overflow-y-hidden" style={{ direction: "ltr" }}>
        <div className="flex gap-3 h-full pb-3" style={{ width: "max-content", minWidth: "100%" }}>
          {COLS.map(col => {
            const colTasks = TASKS.filter(tk => tk.status === col.key);
            return (
              <div key={col.key} className="w-72 flex flex-col gap-2 flex-shrink-0" style={{ direction: lang === "ar" ? "rtl" : "ltr" }}>
                <div className={`flex items-center gap-2 px-3 py-2.5 rounded-xl ${col.hdr}`}>
                  <span className={`w-2 h-2 rounded-full ${col.dot}`} />
                  <span className="text-sm font-semibold text-foreground">{col.label}</span>
                  <span className="ms-auto w-5 h-5 bg-background rounded-full flex items-center justify-center text-[10px] font-bold text-muted-foreground">
                    {colTasks.length}
                  </span>
                </div>
                <div className="flex flex-col gap-2 flex-1 overflow-y-auto">
                  {colTasks.map(task => (
                    <div
                      key={task.id}
                      onClick={() => setSelected(selected === task.id ? null : task.id)}
                      className={`bg-card rounded-xl border ${selected === task.id ? "border-primary shadow-md ring-1 ring-primary/20" : "border-border hover:shadow-sm"} p-3.5 cursor-pointer transition-all group`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <p className="text-sm font-medium text-foreground leading-snug flex-1">
                          {lang === "ar" ? task.title : task.titleEn}
                        </p>
                        <button className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                          <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between mb-3">
                        <PriorityBadge priority={task.priority} lang={lang} />
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          {lang === "ar" ? task.dueDate : task.dueDateEn}
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2.5 border-t border-border/60">
                        <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-md">{task.dept}</span>
                        <div className={`w-6 h-6 ${task.avatarColor} rounded-full flex items-center justify-center text-white text-[10px] font-bold`}>
                          {lang === "ar" ? task.assignee[0] : task.assigneeEn[0]}
                        </div>
                      </div>
                    </div>
                  ))}
                  {colTasks.length === 0 && (
                    <div className="border-2 border-dashed border-border rounded-xl p-6 text-center">
                      <p className="text-sm text-muted-foreground/60">{t.noTasks}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── TasksListPage ────────────────────────────────────────────────
function TasksListPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const [filter, setFilter] = useState("all");
  const filters = [
    { k: "all",        l: lang === "ar" ? "الكل" : "All" },
    { k: "new",        l: lang === "ar" ? "جديد" : "New" },
    { k: "inProgress", l: lang === "ar" ? "قيد التنفيذ" : "In Progress" },
    { k: "completed",  l: lang === "ar" ? "مكتمل" : "Completed" },
  ];
  const rows = filter === "all" ? TASKS : TASKS.filter(tk => tk.status === filter);
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t.taskList}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{rows.length} {t.tasks_count}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20">
          <Plus className="w-4 h-4" />
          {t.addTask}
        </button>
      </div>
      <div className="flex items-center gap-2 mb-5 flex-wrap">
        {filters.map(f => (
          <button key={f.k} onClick={() => setFilter(f.k)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${filter === f.k ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
            {f.l}
          </button>
        ))}
      </div>
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {[t.name, t.status, t.priority, t.assignee, t.dueDate, t.department].map(h => (
                  <th key={h} className="px-4 py-3.5 text-start text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(task => (
                <tr key={task.id} className="border-b border-border/60 last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3.5">
                    <span className="text-sm font-medium text-foreground">{lang === "ar" ? task.title : task.titleEn}</span>
                  </td>
                  <td className="px-4 py-3.5"><StatusBadge status={task.status} lang={lang} /></td>
                  <td className="px-4 py-3.5"><PriorityBadge priority={task.priority} lang={lang} /></td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-2">
                      <div className={`w-6 h-6 ${task.avatarColor} rounded-full flex items-center justify-center text-white text-[10px] font-bold`}>
                        {lang === "ar" ? task.assignee[0] : task.assigneeEn[0]}
                      </div>
                      <span className="text-sm text-foreground whitespace-nowrap">{lang === "ar" ? task.assignee : task.assigneeEn}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5"><span className="text-sm text-muted-foreground whitespace-nowrap">{lang === "ar" ? task.dueDate : task.dueDateEn}</span></td>
                  <td className="px-4 py-3.5"><span className="text-sm text-muted-foreground">{task.dept}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── LeavesPage ───────────────────────────────────────────────────
function LeavesPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const [leaves, setLeaves] = useState(LEAVES);
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t.leaves}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{leaves.length} {t.requests}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20">
          <Plus className="w-4 h-4" />
          {t.requestLeave}
        </button>
      </div>

      <div className="space-y-3">
        {leaves.map(l => (
          <div key={l.id} className="bg-card rounded-2xl border border-border p-4 flex items-center gap-4 hover:shadow-sm transition-shadow">
            <Av letter={l.avatar} color={l.color} size="md" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1.5">
                <span className="font-semibold text-foreground text-sm">{lang === "ar" ? l.employee : l.employeeEn}</span>
                <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{lang === "ar" ? l.type : l.typeEn}</span>
              </div>
              <div className="flex items-center gap-4 flex-wrap">
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Calendar className="w-3.5 h-3.5" />
                  {l.start} — {l.end}
                </span>
                <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  {l.days} {t.days}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <StatusBadge status={l.status} lang={lang} />
              {l.status === "pending" && (
                <>
                  <button onClick={() => setLeaves(prev => prev.map(x => x.id === l.id ? { ...x, status: "approved" } : x))}
                    className="px-3 py-1.5 bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300 rounded-lg text-xs font-semibold hover:bg-green-200 dark:hover:bg-green-900/60 transition-colors">
                    {t.approve}
                  </button>
                  <button onClick={() => setLeaves(prev => prev.map(x => x.id === l.id ? { ...x, status: "rejected" } : x))}
                    className="px-3 py-1.5 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 rounded-lg text-xs font-semibold hover:bg-red-200 dark:hover:bg-red-900/60 transition-colors">
                    {t.reject}
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── EmailPage ────────────────────────────────────────────────────
function EmailPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const [selected, setSelected] = useState<number>(1);
  const [tab, setTab] = useState<"inbox" | "sent">("inbox");
  const sel = EMAILS.find(e => e.id === selected);
  return (
    <div className="flex h-full">
      {/* List panel */}
      <div className="w-80 flex-shrink-0 border-e border-border flex flex-col bg-card overflow-hidden">
        {/* Tabs */}
        <div className="flex gap-1 p-2 border-b border-border">
          {(["inbox", "sent"] as const).map(tabKey => (
            <button key={tabKey} onClick={() => setTab(tabKey)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-semibold transition-colors ${tab === tabKey ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {tabKey === "inbox" ? <Inbox className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
              {tabKey === "inbox" ? t.inbox : t.sent}
              {tabKey === "inbox" && <span className="bg-primary text-primary-foreground rounded-full w-4 h-4 flex items-center justify-center text-[10px] font-bold">١</span>}
            </button>
          ))}
        </div>
        {/* Compose */}
        <div className="p-3 border-b border-border">
          <button className="w-full flex items-center justify-center gap-2 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" />
            {t.compose}
          </button>
        </div>
        {/* Email list */}
        <div className="flex-1 overflow-y-auto">
          {EMAILS.map(email => (
            <div key={email.id} onClick={() => setSelected(email.id)}
              className={`flex gap-3 p-3.5 cursor-pointer border-b border-border/50 transition-colors ${selected === email.id ? "bg-primary/5 border-e-2 border-e-primary" : "hover:bg-muted/40"} ${!email.read ? "bg-blue-50/40 dark:bg-blue-900/10" : ""}`}>
              <div className={`w-9 h-9 ${email.color} rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0 mt-0.5`}>{email.avatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className={`text-xs ${!email.read ? "font-bold text-foreground" : "font-medium text-foreground"} truncate`}>
                    {lang === "ar" ? email.from : email.fromEn}
                  </span>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0">{email.time}</span>
                </div>
                <p className={`text-xs truncate mb-0.5 ${!email.read ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
                  {lang === "ar" ? email.subject : email.subjectEn}
                </p>
                <p className="text-[11px] text-muted-foreground/70 truncate">{email.preview}</p>
              </div>
              {email.starred && <Star className="w-3 h-3 text-amber-400 fill-amber-400 flex-shrink-0 mt-1" />}
            </div>
          ))}
        </div>
      </div>

      {/* Detail panel */}
      <div className="flex-1 flex flex-col overflow-hidden bg-background">
        {sel ? (
          <>
            <div className="px-6 py-4 border-b border-border bg-card flex items-center justify-between flex-shrink-0">
              <div>
                <h2 className="text-base font-semibold text-foreground">{lang === "ar" ? sel.subject : sel.subjectEn}</h2>
                <p className="text-xs text-muted-foreground mt-0.5">{t.from}: {lang === "ar" ? sel.from : sel.fromEn} · {sel.fromEmail}</p>
              </div>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors">
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {t.reply}
                </button>
                <button className="p-2 rounded-xl hover:bg-muted transition-colors">
                  <Star className={`w-4 h-4 ${sel.starred ? "fill-amber-400 text-amber-400" : "text-muted-foreground"}`} />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-2xl" dir={lang === "ar" ? "rtl" : "ltr"}>
                <div className="flex items-center gap-3 mb-5 p-4 bg-card rounded-2xl border border-border">
                  <div className={`w-11 h-11 ${sel.color} rounded-full flex items-center justify-center text-white font-bold text-lg`}>{sel.avatar}</div>
                  <div className="flex-1">
                    <p className="font-semibold text-foreground text-sm">{lang === "ar" ? sel.from : sel.fromEn}</p>
                    <p className="text-xs text-muted-foreground">{sel.fromEmail}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{sel.time}</span>
                </div>
                <div className="text-sm text-foreground leading-loose whitespace-pre-line bg-card rounded-2xl border border-border p-6">
                  {lang === "ar" ? sel.body : sel.bodyEn}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <Mail className="w-14 h-14 text-muted-foreground/20 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">{t.noEmailSelected}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── EmployeesPage ────────────────────────────────────────────────
function EmployeesPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const [search, setSearch] = useState("");
  const rows = EMPLOYEES.filter(e => {
    const q = search.toLowerCase();
    return !q || (lang === "ar" ? e.name : e.nameEn).toLowerCase().includes(q) || e.email.includes(q);
  });
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t.employees}</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{rows.length} {t.employees_count}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors shadow-sm shadow-primary/20">
          <Plus className="w-4 h-4" />
          {t.addEmployee}
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute start-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder={t.search}
          className="w-full max-w-sm ps-10 pe-4 py-2.5 rounded-xl border border-border bg-card text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
        />
      </div>

      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                {[t.name, t.department, t.role, t.status, ""].map((h, i) => (
                  <th key={i} className="px-4 py-3.5 text-start text-xs font-semibold text-muted-foreground uppercase tracking-wider whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(emp => (
                <tr key={emp.id} className="border-b border-border/60 last:border-0 hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 ${emp.color} rounded-full flex items-center justify-center text-white text-sm font-bold`}>{emp.avatar}</div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{lang === "ar" ? emp.name : emp.nameEn}</p>
                        <p className="text-xs text-muted-foreground">{emp.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3.5"><span className="text-sm text-foreground">{lang === "ar" ? emp.dept : emp.deptEn}</span></td>
                  <td className="px-4 py-3.5">
                    <span className="text-sm text-muted-foreground">
                      {lang === "ar" ? (emp.role === "manager" ? "مدير" : "موظف") : (emp.role === "manager" ? "Manager" : "Employee")}
                    </span>
                  </td>
                  <td className="px-4 py-3.5"><StatusBadge status={emp.status} lang={lang} /></td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center justify-end gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"><Eye className="w-4 h-4" /></button>
                      <button className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"><Pencil className="w-4 h-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── SuperAdminPage ───────────────────────────────────────────────
function SuperAdminPage({ t, lang }: { t: Record<string, string>; lang: Lang }) {
  const planCls: Record<string, string> = {
    enterprise:   "bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300",
    professional: "bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300",
    starter:      "bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300",
  };
  const SUPERS = [
    { label: lang === "ar" ? "إجمالي الشركات" : "Total Companies", v: "4", I: Building2, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/20" },
    { label: lang === "ar" ? "إجمالي الموظفين" : "Total Employees", v: "476", I: Users, color: "text-green-500", bg: "bg-green-50 dark:bg-green-900/20" },
    { label: lang === "ar" ? "باقة مؤسسة" : "Enterprise Plans", v: "2", I: Shield, color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/20" },
    { label: lang === "ar" ? "شركات تجريبية" : "Trial Companies", v: "1", I: AlertCircle, color: "text-amber-500", bg: "bg-amber-50 dark:bg-amber-900/20" },
  ];
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t.superAdmin}</h1>
        <p className="text-sm text-muted-foreground mt-0.5">{lang === "ar" ? "إدارة شركات المنصة والاشتراكات" : "Manage platform companies and subscriptions"}</p>
      </div>
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {SUPERS.map(s => {
          const Icon = s.I;
          return (
            <div key={s.label} className="bg-card rounded-2xl border border-border p-5">
              <div className={`w-11 h-11 ${s.bg} rounded-xl flex items-center justify-center mb-3`}><Icon className={`w-5 h-5 ${s.color}`} /></div>
              <div className="text-3xl font-bold text-foreground">{s.v}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>
      <div>
        <h2 className="text-lg font-bold text-foreground mb-4">{t.companies}</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {COMPANIES.map(co => (
            <div key={co.id} className="bg-card rounded-2xl border border-border p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-foreground text-sm">{lang === "ar" ? co.name : co.nameEn}</p>
                    <p className="text-xs text-muted-foreground">{lang === "ar" ? co.admin : co.adminEn}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <StatusBadge status={co.status} lang={lang} />
                  <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${planCls[co.plan]}`}>
                    {t[co.plan] ?? co.plan}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-muted rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{co.employees}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{t.employees_count}</p>
                </div>
                <div className="bg-muted rounded-xl p-3 text-center">
                  <p className="text-2xl font-bold text-foreground">{co.activeUsers}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{t.activeUsers}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── AppSidebar ───────────────────────────────────────────────────
function AppSidebar({ t, lang, page, setPage, collapsed }: {
  t: Record<string, string>; lang: Lang;
  page: Page; setPage: (p: Page) => void; collapsed: boolean;
}) {
  const NAV: { label: string | null; items: { id: Page; icon: ElementType; label: string }[] }[] = [
    { label: null, items: [{ id: "dashboard", icon: LayoutDashboard, label: t.dashboard }] },
    { label: t.tasks, items: [
      { id: "tasks-kanban", icon: LayoutGrid, label: t.kanban },
      { id: "tasks-list", icon: List, label: t.taskList },
    ]},
    { label: t.hr, items: [
      { id: "employees", icon: Users, label: t.employees },
      { id: "leaves", icon: Calendar, label: t.leaves },
    ]},
    { label: t.communication, items: [
      { id: "email", icon: Mail, label: t.email },
    ]},
    { label: t.superAdmin, items: [
      { id: "superadmin", icon: Shield, label: t.companies },
    ]},
  ];
  return (
    <aside className={`${collapsed ? "w-[68px]" : "w-[248px]"} flex-shrink-0 bg-sidebar border-e border-sidebar-border flex flex-col overflow-y-auto overflow-x-hidden transition-[width] duration-200 ease-in-out`}>
      {/* Logo */}
      <div className={`flex items-center gap-3 h-[60px] px-4 border-b border-sidebar-border flex-shrink-0`}>
        <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm shadow-primary/30">
          <CheckSquare className="w-5 h-5 text-white" />
        </div>
        {!collapsed && <span className="font-bold text-[15px] text-foreground tracking-tight">TASK Flow</span>}
      </div>
      {/* Nav */}
      <nav className="flex-1 px-2 py-3">
        {NAV.map((group, gi) => (
          <div key={gi} className={gi > 0 ? "mt-5" : ""}>
            {group.label && !collapsed && (
              <p className="px-3 py-1 mb-1 text-[9px] font-bold uppercase tracking-[0.12em] text-muted-foreground/50">{group.label}</p>
            )}
            {group.items.map(item => {
              const Icon = item.icon;
              const active = page === item.id;
              return (
                <button key={item.id} onClick={() => setPage(item.id)} title={collapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all mb-0.5 border-s-[3px] ${
                    active
                      ? "bg-primary/10 text-primary border-primary"
                      : "border-transparent text-sidebar-foreground/70 hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${active ? "text-primary" : "text-muted-foreground"}`} />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                </button>
              );
            })}
          </div>
        ))}
      </nav>
      {/* User */}
      {!collapsed && (
        <div className="p-3 border-t border-sidebar-border flex-shrink-0">
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-muted transition-colors cursor-pointer">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">أ</div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground truncate">{lang === "ar" ? "أحمد العلي" : "Ahmed Al-Ali"}</p>
              <p className="text-xs text-muted-foreground truncate">{lang === "ar" ? "مدير الشركة" : "Company Admin"}</p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
          </div>
        </div>
      )}
    </aside>
  );
}

// ─── AppTopbar ────────────────────────────────────────────────────
function AppTopbar({ t, lang, setLang, dark, setDark, sidebarCollapsed, setSidebarCollapsed, onLogout, page }: {
  t: Record<string, string>; lang: Lang;
  setLang: (l: Lang) => void; dark: boolean;
  setDark: (d: boolean) => void; sidebarCollapsed: boolean;
  setSidebarCollapsed: (c: boolean) => void;
  onLogout: () => void; page: Page;
}) {
  const [notifOpen, setNotifOpen] = useState(false);
  const PAGE_TITLE: Partial<Record<Page, string>> = {
    dashboard: t.dashboard, "tasks-kanban": t.kanban, "tasks-list": t.taskList,
    leaves: t.leaves, email: t.email, employees: t.employees, superadmin: t.superAdmin,
  };
  const NOTIFS = [
    { id: 1, text: lang === "ar" ? 'مهمة جديدة: "تطوير واجهة المستخدم"' : 'New task assigned: "Develop UI Interface"', time: lang === "ar" ? "منذ ١٠ د" : "10m ago", unread: true },
    { id: 2, text: lang === "ar" ? "وافقت سارة على طلب إجازتك" : "Sara approved your leave request", time: lang === "ar" ? "منذ ١ س" : "1h ago", unread: true },
    { id: 3, text: lang === "ar" ? "رسالة جديدة من محمد الحربي" : "New email from Mohammed Al-Harbi", time: lang === "ar" ? "منذ ٢ س" : "2h ago", unread: false },
  ];
  return (
    <header className="flex items-center justify-between h-[60px] px-4 border-b border-border bg-card flex-shrink-0 z-10">
      <div className="flex items-center gap-3">
        <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
          <Menu className="w-5 h-5" />
        </button>
        <h2 className="text-sm font-bold text-foreground hidden sm:block">{PAGE_TITLE[page] ?? ""}</h2>
      </div>
      <div className="flex items-center gap-1">
        {/* Search */}
        <div className="relative hidden md:flex items-center">
          <Search className="absolute start-3 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
          <input placeholder={t.search}
            className="ps-9 pe-4 py-2 w-48 rounded-xl border border-border bg-input-background text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:w-60 transition-all"
          />
        </div>
        {/* Dark mode */}
        <button onClick={() => setDark(!dark)}
          className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
          {dark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
        </button>
        {/* Language */}
        <button onClick={() => setLang(lang === "ar" ? "en" : "ar")}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl hover:bg-muted transition-colors text-xs font-bold text-muted-foreground hover:text-foreground">
          <Globe className="w-3.5 h-3.5" />
          {lang === "ar" ? "EN" : "عربي"}
        </button>
        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setNotifOpen(v => !v)}
            className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground relative">
            <Bell className="w-4.5 h-4.5" />
            <span className="absolute top-2 end-2 w-1.5 h-1.5 bg-red-500 rounded-full ring-1 ring-card" />
          </button>
          {notifOpen && (
            <div className="absolute top-11 end-0 w-80 bg-card border border-border rounded-2xl shadow-xl z-50 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                <span className="font-bold text-sm text-foreground">{t.notifications}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{lang === "ar" ? "تحديد الكل كمقروء" : "Mark all read"}</span>
                  <button onClick={() => setNotifOpen(false)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
                </div>
              </div>
              {NOTIFS.map(n => (
                <div key={n.id} className={`flex items-start gap-3 px-4 py-3.5 border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors ${n.unread ? "bg-blue-50/30 dark:bg-blue-900/10" : ""}`}>
                  <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.unread ? "bg-blue-500" : "bg-transparent"}`} />
                  <div className="flex-1">
                    <p className="text-xs text-foreground leading-relaxed">{n.text}</p>
                    <p className="text-[11px] text-muted-foreground mt-1">{n.time}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        {/* Logout */}
        <button onClick={onLogout} title={t.logout}
          className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-muted-foreground hover:text-red-500">
          <LogOut className="w-4.5 h-4.5" />
        </button>
      </div>
    </header>
  );
}

// ─── App ──────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<Page>("login");
  const [dark, setDark] = useState(false);
  const [lang, setLang] = useState<Lang>("ar");
  const [collapsed, setCollapsed] = useState(false);
  const t = T[lang];
  const isRTL = lang === "ar";
  const fontFamily = "'Cairo', 'Inter', sans-serif";

  if (page === "login") {
    return (
      <div dir={isRTL ? "rtl" : "ltr"} className={dark ? "dark" : ""} style={{ fontFamily, height: "100vh", overflow: "hidden" }}>
        <div className="h-full bg-background text-foreground">
          <LoginPage t={t} lang={lang} setLang={setLang} dark={dark} setDark={setDark} onLogin={() => setPage("dashboard")} />
        </div>
      </div>
    );
  }

  return (
    <div dir={isRTL ? "rtl" : "ltr"} className={`${dark ? "dark" : ""} h-screen overflow-hidden bg-background text-foreground`} style={{ fontFamily }}>
      <div className="flex h-full">
        <AppSidebar t={t} lang={lang} page={page} setPage={setPage} collapsed={collapsed} />
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <AppTopbar t={t} lang={lang} setLang={setLang} dark={dark} setDark={setDark}
            sidebarCollapsed={collapsed} setSidebarCollapsed={setCollapsed}
            onLogout={() => setPage("login")} page={page}
          />
          <main className={`flex-1 min-h-0 ${page === "email" || page === "tasks-kanban" ? "overflow-hidden" : "overflow-auto"}`}>
            {page === "dashboard"    && <DashboardPage t={t} lang={lang} />}
            {page === "tasks-kanban" && <KanbanPage t={t} lang={lang} />}
            {page === "tasks-list"   && <TasksListPage t={t} lang={lang} />}
            {page === "leaves"       && <LeavesPage t={t} lang={lang} />}
            {page === "email"        && <EmailPage t={t} lang={lang} />}
            {page === "employees"    && <EmployeesPage t={t} lang={lang} />}
            {page === "superadmin"   && <SuperAdminPage t={t} lang={lang} />}
          </main>
        </div>
      </div>
    </div>
  );
}
