
  # Tsak

  This is a code bundle for Tsak. The original project is available at https://www.figma.com/design/5UJW17cFvgESEvqwXaoW9y/Tsak.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  